import React from "react";

const RecipeItem = ({ name, category }) => {
  return (
    <li>
      <h4>{name}</h4>
      <p>{category}</p>
    </li>
  );
};

export default RecipeItem;
