import React from "react";

const AddRecipe = () => {
  return <div>Add recipe</div>;
};

export default AddRecipe;
