import React from "react";

const Error = ({ error }) => {
  return <p>{error.message}</p>;
};

export default Error;
